public class SortingTest {
    public static void main(String[] args) {
        Order[] orders = {
            new Order("001", "Harry", 250.0),
            new Order("002", "Ron", 150.0),
            new Order("003", "Hermoine", 300.0)
        };

        Order[] ordersForBubbleSort = orders.clone();
        SortingAlgorithms.bubbleSort(ordersForBubbleSort);
        System.out.println("Bubble Sort Result:");
        for (Order order : ordersForBubbleSort) 
            System.out.println(order);

        Order[] ordersForQuickSort = orders.clone();
        SortingAlgorithms.quickSort(ordersForQuickSort, 0, ordersForQuickSort.length - 1);
        System.out.println("\nQuick Sort Result:");
        for (Order order : ordersForQuickSort)
            System.out.println(order);
    }
}
