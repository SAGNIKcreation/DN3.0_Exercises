public class InventoryTest {
    public static void main(String[] args) {
        InventoryManager manager = new InventoryManager();

        Product p1 = new Product("001", "Circuits", 10, 1000.00);
        Product p2 = new Product("002", "Wires", 25, 100.00);

        manager.addProduct(p1);
        manager.addProduct(p2);

        System.out.println("\nList of products:");
        manager.listProducts();

        p1.setPrice(950.00);
        manager.updateProduct(p1);


        System.out.println("\nProduct ID 001:");
        System.out.println(manager.getProduct("001"));


        manager.deleteProduct("002");
        
        System.out.println("\nList of products after deletion:");
        manager.listProducts();
    }
}
