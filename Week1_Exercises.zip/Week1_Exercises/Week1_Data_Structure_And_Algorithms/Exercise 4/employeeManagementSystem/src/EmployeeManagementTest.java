public class EmployeeManagementTest {
    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem(10);

        // Add employees
        ems.addEmployee(new Employee(1, "Sagnik", "Manager", 75000));
        ems.addEmployee(new Employee(2, "Rahul", "Developer", 60000));
        ems.addEmployee(new Employee(3, "Aman", "Designer", 50000));

        // Traverse employees
        System.out.println("All Employees:");
        ems.traverseEmployees();

        // Search for an employee
        System.out.println("\n Search for Employee ID 2:");
        Employee emp = ems.searchEmployee(2);
        System.out.println(emp != null ? emp : "Employee not found.");

        // Delete an employee
        System.out.println("\n Delete Employee ID 2:");
        ems.deleteEmployee(2);
        ems.traverseEmployees();

        // Try to delete the same employee again
        System.out.println("\n Try to delete Employee ID 2 again:");
        ems.deleteEmployee(2);
        ems.traverseEmployees();
    }
}
