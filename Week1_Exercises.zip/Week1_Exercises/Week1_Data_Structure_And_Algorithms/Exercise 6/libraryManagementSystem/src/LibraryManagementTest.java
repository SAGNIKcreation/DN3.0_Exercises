public class LibraryManagementTest {
    public static void main(String[] args) {
        Library library = new Library();
        
        library.addBook(new Book(001, "Harry Potter", "J K Rowling"));
        library.addBook(new Book(002, "A Song of Ice and Fire", "George R R Martin"));
        library.addBook(new Book(003, "A Visit from the Goon Squad", "Jennifer Egan"));
        library.addBook(new Book(004, "The Buddha in the Atic", "Julie Otsuka"));
        library.addBook(new Book(005, "Pride and Prejudice", "Jane Austen"));

        System.out.println(" Linear Search:");
        Book book = library.linearSearchByTitle("A Song of Ice and Fire");
        System.out.println(book != null ? book : "Book not found.");

        library.sortBooksByTitle();

        System.out.println("\n Binary Search:");
        book = library.binarySearchByTitle("A Song of Ice and Fire");
        System.out.println(book != null ? book : "Book not found.");
    }
}
