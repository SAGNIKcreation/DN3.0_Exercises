public class StripePaymentGateway {
    public void makePayment(double amount) {
        System.out.println("Processing payment ₹" + amount + " via Stripe.");
    }
}
