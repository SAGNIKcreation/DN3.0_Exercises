public class AdapterPatternTest {
    public static void main(String[] args) {
        StripePaymentGateway stripeGateway = new StripePaymentGateway();
        PayPalPaymentGateway payPalGateway = new PayPalPaymentGateway();
        
        PaymentProcessor stripeAdapter = new StripeAdapter(stripeGateway);
        PaymentProcessor payPalAdapter = new PayPalAdapter(payPalGateway);
        
        stripeAdapter.processPayment(150.00);
        payPalAdapter.processPayment(225.00);
    }
}
