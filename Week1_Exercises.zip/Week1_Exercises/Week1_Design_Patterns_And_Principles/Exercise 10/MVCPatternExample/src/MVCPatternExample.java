public class MVCPatternExample {
    public static void main(String[] args) {
 
        Student student = new Student("001", "Sagnik Sanyal", "A");
        StudentView view = new StudentView();
        StudentController controller = new StudentController(student, view);

        controller.updateView();

        System.out.println("Updated Student Details: ");
        controller.setStudentName("Sagnik Sanyal");
        controller.setStudentGrade("B");

        controller.updateView();
    }
}
