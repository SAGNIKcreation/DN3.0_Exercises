public class SingletonTest {
    public static void main(String[] args) {
        Logger logg1 = Logger.getinst();
        Logger logg2 = Logger.getinst();
        if (logg1 == logg2)
            System.out.println("Same logger instances.");
        else
            System.out.println("Different logger instances.");

        logg1.log("A log message.");
        logg2.log("Another log message.");
    }
}
