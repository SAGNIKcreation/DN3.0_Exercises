CREATE TABLE Customers ( 
    CustomerID NUMBER PRIMARY KEY, 
    Name VARCHAR2(100), 
    DOB DATE, 
    Balance NUMBER, 
    LastModified DATE 
);

CREATE TABLE Accounts ( 
    AccountID NUMBER PRIMARY KEY, 
    CustomerID NUMBER, 
    AccountType VARCHAR2(20), 
    Balance NUMBER, 
    LastModified DATE, 
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID) 
);

CREATE TABLE Transactions ( 
    TransactionID NUMBER PRIMARY KEY, 
    AccountID NUMBER, 
    TransactionDate DATE, 
    Amount NUMBER, 
    TransactionType VARCHAR2(10), 
    FOREIGN KEY (AccountID) REFERENCES Accounts(AccountID) 
);

CREATE TABLE Loans ( 
    LoanID NUMBER PRIMARY KEY, 
    CustomerID NUMBER, 
    LoanAmount NUMBER, 
    InterestRate NUMBER, 
    StartDate DATE, 
    EndDate DATE, 
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID) 
);

CREATE TABLE Employees ( 
    EmployeeID NUMBER PRIMARY KEY, 
    Name VARCHAR2(100), 
    Position VARCHAR2(50), 
    Salary NUMBER, 
    Department VARCHAR2(50), 
    HireDate DATE 
);

INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified) 
VALUES (1, 'John Doe', TO_DATE('1985-05-15', 'YYYY-MM-DD'), 1000, SYSDATE);

INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified) 
VALUES (2, 'Jane Smith', TO_DATE('1990-07-20', 'YYYY-MM-DD'), 1500, SYSDATE);

INSERT INTO Accounts (AccountID, CustomerID, AccountType, Balance, LastModified) 
VALUES (1, 1, 'Savings', 1000, SYSDATE);

INSERT INTO Accounts (AccountID, CustomerID, AccountType, Balance, LastModified) 
VALUES (2, 2, 'Checking', 1500, SYSDATE);

INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType) 
VALUES (1, 1, SYSDATE, 200, 'Deposit');

INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType) 
VALUES (2, 2, SYSDATE, 300, 'Withdrawal');

INSERT INTO Loans (LoanID, CustomerID, LoanAmount, InterestRate, StartDate, EndDate) 
VALUES (1, 1, 5000, 5, SYSDATE, ADD_MONTHS(SYSDATE, 60));

INSERT INTO Employees (EmployeeID, Name, Position, Salary, Department, HireDate) 
VALUES (1, 'Alice Johnson', 'Manager', 70000, 'HR', TO_DATE('2015-06-15', 'YYYY-MM-DD'));

INSERT INTO Employees (EmployeeID, Name, Position, Salary, Department, HireDate) 
VALUES (2, 'Bob Brown', 'Developer', 60000, 'IT', TO_DATE('2017-03-20', 'YYYY-MM-DD'));

CREATE OR REPLACE PROCEDURE SafeTransferFunds ( 
    p_from_account_id IN NUMBER, 
    p_to_account_id IN NUMBER, 
    p_amount IN NUMBER 
) IS 
    insufficient_funds EXCEPTION; 
    v_balance NUMBER; 
BEGIN 
    SELECT Balance INTO v_balance 
    FROM Accounts 
    WHERE AccountID = p_from_account_id 
    FOR UPDATE; 
 
    IF v_balance < p_amount THEN 
        RAISE insufficient_funds; 
    END IF; 
 
    UPDATE Accounts 
    SET Balance = Balance - p_amount 
    WHERE AccountID = p_from_account_id; 
 
    UPDATE Accounts 
    SET Balance = Balance + p_amount 
    WHERE AccountID = p_to_account_id; 
 
    COMMIT; 
EXCEPTION 
    WHEN insufficient_funds THEN 
        ROLLBACK; 
        DBMS_OUTPUT.PUT_LINE('Insufficient amount.'); 
    WHEN OTHERS THEN 
        ROLLBACK; 
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM); 
END SafeTransferFunds; 
/

BEGIN
    		SafeTransferFunds(1, 2, 500);
END;
/


