public class PayPalPaymentGateway {
    public void executePayment(double amount) {
        System.out.println("Processing payment ₹" + amount + " via PayPal.");
    }
}
