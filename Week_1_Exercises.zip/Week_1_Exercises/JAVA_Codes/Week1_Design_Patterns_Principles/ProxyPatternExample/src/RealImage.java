import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class RealImage implements Image {
    private String filename;
    private BufferedImage image;
    public RealImage(String filename) {
        this.filename = filename;
        loadImageFromDisk();
    }
    private void loadImageFromDisk() {
        System.out.println("Loading image: " + filename);
        try {
            File file = new File(filename);
            if (!file.exists())
                throw new IOException("File not found: " + filename);
            image = ImageIO.read(file);
            Thread.sleep(2000);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void display() {
        System.out.println("Display image: " + filename);
        if (image != null)
            System.out.println("Dimension of the image: " + image.getWidth() + "x" + image.getHeight());
    }
}
