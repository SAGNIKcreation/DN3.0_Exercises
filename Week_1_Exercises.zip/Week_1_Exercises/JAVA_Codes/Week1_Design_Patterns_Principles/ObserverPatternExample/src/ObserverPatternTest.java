public class ObserverPatternTest {
    public static void main(String[] args) {
        StockMarket stockMarket = new StockMarket();

        Observer mobileApp1 = new MobileApp("Mobile Application 1");
        Observer mobileApp2 = new MobileApp("Mobile Application 2");
        Observer webApp1 = new WebApp("Web Application 1");

        stockMarket.registerObserver(mobileApp1);
        stockMarket.registerObserver(mobileApp2);
        stockMarket.registerObserver(webApp1);
        
        stockMarket.setStockPrice(100.0);
        System.out.println();
        stockMarket.setStockPrice(155.5);
        System.out.println();
        stockMarket.deregisterObserver(mobileApp1);
        stockMarket.setStockPrice(115.0);
    }
}
