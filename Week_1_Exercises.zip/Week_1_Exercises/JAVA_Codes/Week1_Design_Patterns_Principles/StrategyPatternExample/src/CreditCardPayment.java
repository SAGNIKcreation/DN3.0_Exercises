import java.util.Random;

public class CreditCardPayment implements PaymentStrategy {
    private String cardNumber;
    private String cardHolderName;
    private String cvv;
    private String expiryDate;
    public CreditCardPayment(String cardNumber, String cardHolderName, String cvv, String expiryDate) {
        this.cardNumber = cardNumber;
        this.cardHolderName = cardHolderName;
        this.cvv = cvv;
        this.expiryDate = expiryDate;
    }
    public void pay(double amount) {
        System.out.println("Card Number: " + cardNumber);
        System.out.println("Card Holder Name: " + cardHolderName);
        System.out.println("CVV: " + cvv);
        System.out.println("Expiry Date: " + expiryDate);
        System.out.println("Amount: " + amount);

        boolean paymentSuccessful = new Random().nextBoolean();
        
        if (paymentSuccessful)
            System.out.println("Payment of ₹" + amount + " was successful with Credit Card.");
        else 
            System.out.println("Payment of ₹" + amount + " failed for Credit Card.");
    }
}
