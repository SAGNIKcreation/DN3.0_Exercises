import java.util.Random;

public class PayPalPayment implements PaymentStrategy {
    private String email;
    private String password;
    public PayPalPayment(String email, String password) {
        this.email = email;
        this.password = password;
    }
    public void pay(double amount) {
        System.out.println("PayPal Account: " + email);        
        System.out.println("Password: " + password);
        System.out.println("Amount: " + amount);

        // Simulate payment processing
        boolean paymentSuccessful = new Random().nextBoolean();
        
        if (paymentSuccessful)
            System.out.println("Payment of ₹" + amount + " was successful using PayPal.");
        else
            System.out.println("Payment of ₹" + amount + " failed using PayPal.");
    }
}
