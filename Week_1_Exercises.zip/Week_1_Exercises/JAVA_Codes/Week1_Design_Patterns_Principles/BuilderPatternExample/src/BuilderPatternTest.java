public class BuilderPatternTest {
    public static void main(String[] args) {
        Computer computer1 = new Computer.Builder("Intel i5", 8)
                .setStorage(512)
                .setGraphicsCard(true)
                .setWiFi(true)
                .build();
        
        Computer computer2 = new Computer.Builder("AMD Ryzen 7", 16)
                .setStorage(256)
                .build();
        
        System.out.println(computer1);
        System.out.println(computer2);
    }
}
