public class DecoratorPatternTest {
    public static void main(String[] args) {

        Notifier emailNotifier = new EmailNotifier();
        Notifier smsEmailNotifier = new SMSNotifierDecorator(emailNotifier);
        Notifier slackSMSEmailNotifier = new SlackNotifierDecorator(smsEmailNotifier);

        slackSMSEmailNotifier.send("I am Sagnik Sanyal!");
    }
}
