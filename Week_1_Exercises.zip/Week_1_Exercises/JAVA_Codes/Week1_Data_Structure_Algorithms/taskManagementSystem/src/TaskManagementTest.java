public class TaskManagementTest {
    public static void main(String[] args) {
        TaskLinkedList taskList = new TaskLinkedList();

        taskList.addTask(new Task(1, "Build UI/UX", "Done"));
        taskList.addTask(new Task(2, "Build Front-end", "In Progress"));
        taskList.addTask(new Task(3, "Implement Back-end", "Pending"));

        System.out.println("All Tasks:");
        taskList.traverseTasks();

        System.out.println("\n Search for Task ID 2:");
        Task task = taskList.searchTask(2);
        System.out.println(task != null ? task : "Task not found.");

        System.out.println("\n Delete Task ID 2:");
        taskList.deleteTask(2);
        taskList.traverseTasks();

        System.out.println("\n Try to delete Task ID 2 again:");
        taskList.deleteTask(2);
        taskList.traverseTasks();
    }
}
